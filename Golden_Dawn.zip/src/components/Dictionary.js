import React from "react";
import card from "../img/card.jpg";

const Dictionary = () => {
  return (
    <div className="dictWrapper">
      <h1>Major Arcana</h1>
      <div className="dictCardsWrapper"> 
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
        <img src={card} />
      </div>
    </div>
  )
}

export default Dictionary;