import React from 'react';
import ReactDom from 'react-dom';
import App from "./App";
import style from "./main.scss";

ReactDom.render(<App className="wrapper"/>, document.getElementById('root'));
